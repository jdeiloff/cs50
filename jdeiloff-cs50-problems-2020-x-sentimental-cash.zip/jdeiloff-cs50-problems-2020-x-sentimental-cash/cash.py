import cs50

C = cs50.get_float("Change owed: ")  #Get the change owed value using get_float from cs50 lib

while (C < 0):
    C = cs50.get_float("Change owed: ")   #Prompts for input if negative value is inserted
coin = 0
c = (C*100)    # Multiplies the given value for easier coin counter

while c >= 25:    # Quarters
    c = c-25
    coin += 1
    
while c >= 10:    # Dimes
    c = c-10
    coin += 1

while c >= 5:    # Nickels
    c = c-5
    coin +=1
    
while (c >= 1):  # Pennies
    c = c-1
    coin +=1

print (coin)