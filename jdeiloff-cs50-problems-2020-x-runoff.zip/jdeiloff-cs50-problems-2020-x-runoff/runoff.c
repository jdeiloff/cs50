#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <cs50.h>
#include <math.h>

#define MAX 9       //declared new variable and structs

typedef struct
{
    string name;
    int votes;
    bool eliminated;
}
candidate;

candidate candidates[MAX];    //dunno what else to comment

int voter_count;
int candidate_count;
int preferences[MAX][MAX];
float winner_vote;


bool is_tie(int min);         //check_preference(void);
bool vote(int voter, int rank, string name);
bool print_winner(void);
void tabulate(void);
int find_min(void);
void eliminate(int min);


int main(int argc, string argv[])
{
    if (argc < 2)
    {
        printf("Usage: give candidates names...]\n"); //how to use if given invalid string
        return 1;
    }

    candidate_count = argc - 1;

    if (candidate_count > MAX)
    {
        printf("Maximum number of candidates is %i\n", MAX); //maximum number of candidates
        return 2;
    }



    for (int i = 0; i < candidate_count ; i++) //number of candidates given, starts to count votes and being no eliminated
    {
        candidates[i].name = argv[i + 1];
        candidates[i].votes = 0;
        candidates[i].eliminated = false;
    }

    voter_count = get_int("Number of voters: "); //takes int number of voters in the runoff

    winner_vote = voter_count / 2;
    int integer = winner_vote;

    if (winner_vote == integer)
    {
        winner_vote++;
    }
    else
    {
        winner_vote = ceil(winner_vote); //another comment
    }

    for (int i = 0; i < voter_count; i++)
    {
        for (int j = 0; j < candidate_count; j++)
        {


            string name = get_string("Rank %i ", j + 1); //rank of the runoff vote

            if (!vote(i, j, name))

            {
                printf("Invalid vote\n");   //if it given name is not a valid candidate
                j--;
            }

        }
        printf("\n");  //s
    }




    while (true)
    {
        tabulate();  //check preferences of the received vote

        if (print_winner())
        {
            return 1;
        }
        else if (is_tie(find_min()))
        {
            return 1;
        }
        else
        {
            eliminate(find_min()); //comment
        }

    }
}


void eliminate(int min)  //eliminate the candidate if votes are not enough
{
    for (int i = 0; i < candidate_count; i++)
    {
        if (candidates[i].eliminated)
        {
            continue;
        }
        else if (min == candidates[i].votes)
        {
            candidates[i].eliminated = true;
        }
    }

}




int find_min(void)
{
    int min = MAX;             //checks if candidate has the minumum number of votes to keep it in the runoff
    for (int i = 1; i < candidate_count; i++)
    {
        if (candidates[i].eliminated)
        {
            continue;
        }
        else if (min > candidates[i].votes)
        {
            min = candidates[i].votes;
        }
    }

    return min;



}


bool is_tie(int min)
{
    for (int i = 0; i < candidate_count; i++)   //checks if votes for a candidate in a rank are tied
    {
        if (candidates[i].eliminated)
        {
            continue;
        }
        else if (min == candidates[i].votes)
        {
            continue;
        }
        else
        {
            return 0;
        }
    }
    return 1;
}



bool vote(int voter, int rank, string name)
{
    bool exist = false;



    for (int i = 0; i < candidate_count; i++)
    {
        if (strcmp(name, candidates[preferences[voter][i]].name) == 0
            && rank > 0) //add votes sorting its importance in rank 1st vote, higher rank
        {
            return 0;
        }

        if (strcmp(name, candidates[i].name) == 0)
        {

            preferences[voter][rank] = i;
            exist = true;
            break;
        }
    }

    return exist;
}

//what else can i say

bool print_winner(void)
{
    int maj = voter_count / 2;  //prints the winner of the runoff
    for (int i = 0; i < candidate_count; i++)
    {
        if (candidates[i].votes > maj)
        {
            printf("%s\n", candidates[i].name);
            return true;
        }
    }
    return false;
}

void tabulate(void)
{
    int check = 0;
    for (int i = 0; i < voter_count; i++)
    {
        if (!candidates[preferences[i][check]].eliminated) //checks if voted candidate has been eliminated from the runoff
        {
            candidates[preferences[i][check]].votes++;
            check = 0;
        }
        else
        {
            check++;
            i--;
        }
    }
}