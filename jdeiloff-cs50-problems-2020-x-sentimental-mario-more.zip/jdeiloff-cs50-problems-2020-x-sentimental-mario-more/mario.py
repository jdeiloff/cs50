import cs50

s = cs50.get_int("Size= ") # Gets the size as an int input

while(s < 1 or s > 8): # Keeps asking for input if not between 1 and 8
    s = cs50.get_int("Size= ")

for i in range(s):  # Prints " " starting from i=0 (s-i) times, and prints "#" (i+1) times in the range given by s
    print(" "*(s-i) + "#"*(i+1) + "  " + "#"*(i+1) + " "*(s-i))
