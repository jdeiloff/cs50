#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

int main(void)
{
    string text = 
        get_string("Text: ");            /*It gets and holds the text to be analyzed using the Coleman-Lieau index to check the grade*/

    float letters = 0, words = 1, sentences = 0;   /*It creates the counters for letters, words and sentences*/
    for (int i = 0, n = strlen(text); i < n; i++)
    {
        if (isalpha(text[i]))
        {
            letters++;                         /*Numer of letters*/
        }
        if (isspace(text[i]))
        {
            words++;                          /*Numer of words*/
        }
        if (text[i] == '.' || text[i] == '!' || text[i]  == '?')    /*It gets the end of sentence signs*/
        {
            sentences++;
        }

    }
    float l = letters / words * 100;
    float s = sentences / words * 100;
    float index = 0.0588 * l - 0.296 * s - 15.8;    /*Coleman-Liau Index formula*/
    int indexa = round(index);

    if (indexa >= 1 && indexa <= 16)      /*Coleman-Liau Index of approximated required grade to read the text*/
    {
        printf("Grade %i\n", indexa);
    }
    else
    {
        if (indexa < 1)
        {
            printf("Before Grade 1\n");
        }
        if (indexa > 16)
        {
            printf("Grade 16+\n");
        }
    }
}