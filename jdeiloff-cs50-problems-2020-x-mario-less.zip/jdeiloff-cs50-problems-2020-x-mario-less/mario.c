#include <cs50.h>
#include <stdio.h>

int main(void)
{
    int n;
    do
    {
        //input here
        n = get_int("Size= ");
    }
         //only input between 1 and 8 are accepted, insist if no correct value is inserted
    while (n < 1 || n > 8);
    for (int l = 0; l < n; l++)
    {
        for (int k = 0; k < n; k++)
{ 
    if (l + k < n - 1)

       //blankspaces of the pyramid

       printf(" ");

        else

       //bricks of the pyramids, hashes here

         printf("#");
        }

        printf("\n");

    }
}
