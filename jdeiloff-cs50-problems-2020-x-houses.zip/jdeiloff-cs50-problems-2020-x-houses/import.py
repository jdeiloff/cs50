from cs50 import SQL
import csv
import sys
import re

# Exits program if not enough arguments are given
if len(sys.argv) !=2:
    print("Error, usage is import.py (-database) 'file.csv'")
    exit(1)
    
# Open students database file
db = SQL("sqlite:///students.db")

# Gets first argument as csv file and open csv file
with open(sys.argv[1], "r") as csvfile:
    datareader = csv.reader(csvfile)
    for char in datareader:
        if char[0] == "name":
            continue

# Split name row in csv file into first, middle and last name        
        Name = char[0].split()

# Insert info into students database file
        if len(Name) < 3:
            db.execute("INSERT INTO students(first, middle, last, house, birth) VALUES(?, ?, ?, ?, ?)",
                Name[0], None, Name[1], char[1], char[2])
        else:
            db.execute("INSERT INTO students(first, middle, last, house, birth) VALUES(?, ?, ?, ?, ?)",
                Name[0], Name[1], Name[2], char[1], char[2])