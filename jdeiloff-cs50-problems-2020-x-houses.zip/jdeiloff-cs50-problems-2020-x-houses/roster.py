import sys
from cs50 import SQL

# Exits program if not enough arguments are given
if len(sys.argv) !=2:
    print("Error, usage is roster.py (--House Name--)")
    exit(1)

# Open the database and executes a query listing people from a given house in alphabetical order
db = SQL("sqlite:///students.db")
students = db.execute("SELECT DISTINCT * FROM students WHERE house = (?) ORDER BY last, first", sys.argv[1])

# Print out info about people of given house, including full name, if it has no middle name, it only shows first and last
for student in students:
    if student['middle'] != None:
        print(f"{student['first']} {student['middle']} {student['last']}, born {student['birth']}")
    else:
        print(f"{student['first']} {student['last']}, born {student['birth']}")