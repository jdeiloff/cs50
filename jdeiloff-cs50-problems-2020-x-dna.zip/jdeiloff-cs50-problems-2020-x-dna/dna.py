import csv
import sys
import re
import collections
import numpy

def main():
#Exits program if there are not 3 arguments given
    if len(sys.argv) < 3:
        print("Error, usage is dna.py (-database) 'file.csv' (-sequence) 'file.txt'")
        exit(1)

    #Open the sequence txt file
    with open(sys.argv[2], 'r') as seqfile:
        sq = seqfile.read()

    #Open the database as csv file, declares lists to load info in
    info = []
    dnastrinfo = []
    with open(sys.argv[1], 'r') as csvfile:
        reader = csv.reader(csvfile)
        #has_header = csv.Sniffer().has_header
            #if has_header !=None:
            #next(reader)
        line = 0
        for row in reader:
            if line == 0:
                dnastrinfo = row
                line += 1
            else:
                info.append(row)

    #Sequences DNA STRs and stores them into a list
    strcount = []
    for i in range(1, len(dnastrinfo)):
        strcount.append(sequencer(dnastrinfo[i], sq))
    strcount = numpy.array(strcount)

    #Compares DNA STRs with the sequences and stores them into a list
    for i in range(len(info)):
        t = numpy.array(info[i][1:])
        if (t == strcount).all():
            suspect = info[i][0]
            break
        else:
            suspect = "No match"
    print(suspect)

#Defines the sequencer function to count STRs using RE (lamdba doesnt work)
def sequencer(K, Q):
    p = re.compile(rf'({K})\1*')
    max = 0
    match = [match for match in p.finditer(Q)]
    for i in range(len(match)):
        if match[i].group().count(K) > max:
            max = match[i].group().count(K)
    return str(max)

main()