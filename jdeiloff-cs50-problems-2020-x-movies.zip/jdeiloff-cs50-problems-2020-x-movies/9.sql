SELECT name FROM people JOIN stars JOIN movies ON people.id = stars.person_id AND movies.id = movie_id WHERE movies.year = "2004"
GROUP BY people.id ORDER BY people.birth;