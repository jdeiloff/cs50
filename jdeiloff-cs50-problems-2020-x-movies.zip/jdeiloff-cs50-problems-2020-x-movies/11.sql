SELECT title FROM movies 
JOIN people JOIN stars JOIN ratings ON people.id = stars.person_id AND movies.id = stars.movie_id AND ratings.movie_id = movies.id
WHERE people.name = "Chadwick Boseman" ORDER BY rating DESC LIMIT 5;