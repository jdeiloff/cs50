#include "helpers.h"
#include <math.h>

// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    float rgbgray;

    for (int i = 0; i < width; i++)
    {
        for (int j = 0; j < height; j++)
        {
            // it gets the average value of the RGB of a pixel and applies it to all colors to get the gray equivalent value.
            rgbgray = round((image[j][i].rgbtBlue + image[j][i].rgbtGreen + image[j][i].rgbtRed) / 3.000);
            image[j][i].rgbtBlue = rgbgray;
            image[j][i].rgbtGreen = rgbgray;
            image[j][i].rgbtRed = rgbgray;
        }
    }
    return;
}

//limits value to 255
int limit(int RGB)
{
    if (RGB > 255)
    {
        RGB = 255;
    }
    return RGB;
}


// Convert image to sepia
void sepia(int height, int width, RGBTRIPLE image[height][width])
{
    int sblue;
    int sgreen;
    int sred;
    for (int i = 0; i < width; i++)
    {
        for (int j = 0; j < height; j++)
            //uses the sepia formula and applies to the RGB value to get the sepia equivalent value of the image.
        {
            sblue = limit(round(0.272 * image[j][i].rgbtRed + 0.534 * image[j][i].rgbtGreen + 0.131 * image[j][i].rgbtBlue));
            sgreen = limit(round(0.349 * image[j][i].rgbtRed + 0.686 * image[j][i].rgbtGreen + 0.168 * image[j][i].rgbtBlue));
            sred = limit(round(0.393 * image[j][i].rgbtRed + 0.769 * image[j][i].rgbtGreen + 0.189 * image[j][i].rgbtBlue));

            image[j][i].rgbtBlue = sblue;
            image[j][i].rgbtGreen = sgreen;
            image[j][i].rgbtRed = sred;
        }
    }
    return;
}

// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{
    // temporary array to swap values horizontally
    int temp[3];
    for (int i = 0; i < width / 2; i++)
    {
        for (int j = 0; j < height; j++)
        {
            temp[0] = image[j][i].rgbtBlue;
            temp[1] = image[j][i].rgbtGreen;
            temp[2] = image[j][i].rgbtRed;

            //swap rgb values horizontally
            image[j][i].rgbtBlue = image[j][width - i - 1].rgbtBlue;
            image[j][i].rgbtGreen = image[j][width - i - 1].rgbtGreen;
            image[j][i].rgbtRed = image[j][width - i - 1].rgbtRed;

            image[j][width - i - 1].rgbtBlue = temp[0];
            image[j][width - i - 1].rgbtGreen = temp[1];
            image[j][width - i - 1].rgbtRed = temp[2];
        }
    }
    return;
}

// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{
    int medblue;
    int medgreen;
    int medred;
    float counter;
    //temporary values for the color median
    RGBTRIPLE temp[height][width];


    for (int i = 0; i < width; i++)
    {
        for (int j = 0; j < height; j++)
        {
            medblue = 0;
            medgreen = 0;
            medred = 0;
            counter = 0.00;

            //the sum value of the surrounding pixels of a pixel
            for (int k = -1; k < 2; k++)
            {
                if (j + k < 0 || j + k > height - 1)
                {
                    continue;
                }

                for (int h = -1; h < 2; h++)

                {
                    if (i + h < 0 || i + h > width - 1)
                    {
                        continue;
                    }

                    medblue += image[j + k][i + h].rgbtBlue;
                    medgreen += image[j + k][i + h].rgbtGreen;
                    medred += image[j + k][i + h].rgbtRed;
                    counter++;

                }
            }
            //calculates average of the sum of the sorrounding pixels value
            temp[j][i].rgbtBlue = round(medblue / counter);
            temp[j][i].rgbtGreen = round(medgreen / counter);
            temp[j][i].rgbtRed = round(medred / counter);
        }
    }

    //copies the values of the temporary table to the final table
    for (int i = 0; i < width; i++)
    {
        for (int j = 0; j < height; j++)
        {
            image[j][i].rgbtBlue = temp[j][i].rgbtBlue;
            image[j][i].rgbtGreen = temp[j][i].rgbtGreen;
            image[j][i].rgbtRed = temp[j][i].rgbtRed;
        }
    }
    return;
}
